# Craftable Elytra
Adds a recipe for the elytra!

![recipe](https://github.com/Craemon/Craftable-Elytra/assets/121398546/1eb33a0f-4c63-4b2c-b6b5-ba3e102e0b24)

